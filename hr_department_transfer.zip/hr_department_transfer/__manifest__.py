{
    'name': 'Employee Department Transfer',
    'version': '17.0.1.0.0',
    'category': 'Human Resources',
    'summary': 'Manage and track employee department transfers with history and chatter logging.',
    'author': 'Yohanes',
    'depends': ['hr', 'mail'],
    'data': [
        'security/ir.model.access.csv',
        'views/hr_department_transfer_views.xml',
    ],
    'installable': True,
    'application': False,
    'license': 'LGPL-3',
}