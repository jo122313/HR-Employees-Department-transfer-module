from markupsafe import Markup
from odoo import models, fields, api, _
from odoo.exceptions import UserError

class HrDepartmentTransfer(models.Model):
    _name = 'hr.department.transfer'
    _description = 'Employee Department Transfer'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'id desc'

    name = fields.Char(
        string='Reference', 
        required=True, 
        copy=False, 
        readonly=True, 
        default=lambda self: _('New')
    )
    current_department_id = fields.Many2one(
        'hr.department', 
        string='Current Department', 
        required=True, 
        tracking=True
    )
    employee_ids = fields.Many2many(
        'hr.employee', 
        string='Employees to Transfer', 
        required=True,
        domain="[('department_id', '=', current_department_id)]"
    )
    new_department_id = fields.Many2one(
        'hr.department', 
        string='New Department', 
        required=True, 
        tracking=True
    )
    transfer_date = fields.Date(
        string='Transfer Date', 
        default=fields.Date.context_today, 
        required=True
    )
    state = fields.Selection([
        ('draft', 'Draft'),
        ('done', 'Transferred')
    ], string='Status', default='draft', tracking=True)

    @api.onchange('current_department_id')
    def _onchange_current_department_id(self):
        """ Reset employee selection when current department changes """
        self.employee_ids = [(5, 0, 0)]

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', _('New')) == _('New'):
                vals['name'] = self.env['ir.sequence'].next_by_code('hr.department.transfer') or _('New')
            vals['state'] = 'draft'
        return super().create(vals_list)

    def action_execute_transfer(self):
        """ Validates inputs, executes employee batch updates, and posts safe chatter logs """
        for rec in self:
            if rec.state == 'done':
                raise UserError(_("This transfer has already been executed."))

            if rec.current_department_id == rec.new_department_id:
                raise UserError(_("The current department and new department cannot be the same."))

            if not rec.employee_ids:
                raise UserError(_("Please select at least one employee to transfer."))

            transferred_summary = []

            # Capture snapshot data prior to write
            employee_data = [
                (emp, emp.name, emp.department_id.name or _('No Department')) 
                for emp in rec.employee_ids
            ]

            # Batch update employee records in single query
            rec.employee_ids.write({'department_id': rec.new_department_id.id})

            # Process chatter messages
            for employee, emp_name, old_dept_name in employee_data:
                new_dept_name = rec.new_department_id.name

                # Chatter post on individual HR Employee record
                emp_msg = _(
                    "<b>%(emp)s</b> transferred from <b>%(old)s</b> to <b>%(new)s</b>.",
                    emp=emp_name, old=old_dept_name, new=new_dept_name
                )
                employee.message_post(body=emp_msg)

                # Transfer document summary line
                summary_line = _(
                    "<b>%(emp)s</b> transferred from <b>%(old)s</b> to <b>%(new)s</b>",
                    emp=emp_name, old=old_dept_name, new=new_dept_name
                )
                transferred_summary.append(summary_line)

            # Transition state
            rec.write({'state': 'done'})

            # Join summary lines into Transfer Document Chatter
            log_body = Markup("<br/>").join([Markup(line) for line in transferred_summary])
            rec.message_post(body=log_body)